import { ref } from 'vue';

const getAllPosts = () => {
    const posts = ref(null);
    const error = ref(null);

    const load = async () => {
        try {
            let response = await fetch('https://jsonplaceholder.typicode.com/posts');
            if (!response.ok) {
                throw Error('No data available');
            }
            posts.value = await response.json();
        } catch (err) {
            error.value = err.message;
            console.log(error.value);
        }
    };

    return { posts, error, load };
};

export default getAllPosts;
