<script setup>
import DataTable from './components/DataTable.vue'
</script>

<template>
<DataTable />
</template>


