<template>
  <div v-if="posts && posts.length">
    <v-data-table
      :items-per-page="itemsPerPage"
      :headers="headers"
      :items="posts"
      item-value="userId"
      class="elevation-1"
    >
    </v-data-table>
  </div>
  <div v-else>
    <p>No posts available.</p>
  </div>
</template>

<script>
import { ref, onMounted } from "vue";
import { VDataTable } from "vuetify/components";
import getAllPosts from "../getPosts.js";

export default {
  components: {
    VDataTable,
  },
  setup() {
    const { posts, error, load } = getAllPosts();
    const itemsPerPage = ref(10);
    const headers = [
      {
        text: "User Id",
        align: "start",
        sortable: false,
        value: "userId",
      },
      {
        text: "Title",
        align: "start",
        value: "title",
      },
      {
        text: "Body",
        align: "start",
        value: "body",
      },
    ];

    onMounted(() => {
      load();
    });

    return {
      posts,
      error,
      itemsPerPage,
      headers,
    };
  },
};
</script>

<style lang=""></style>
