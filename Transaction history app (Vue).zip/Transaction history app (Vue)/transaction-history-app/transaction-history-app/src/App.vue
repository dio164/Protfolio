<template>
  <v-app>
    <v-main>
      <HelloWorld />
    </v-main>

    <AppFooter />
  </v-app>
</template>

<script setup>
  //
</script>
